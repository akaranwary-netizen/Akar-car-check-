# Akar's Car Check

A starter UK vehicle-check website using Node.js + Express.

## Run it

```bash
npm install
cp .env.example .env
npm start
```

Open http://localhost:3000

Without API credentials the site uses clearly labelled demo vehicle data so you can test the design.

## Connect DVLA

Add your DVLA Vehicle Enquiry Service API key to `.env`:

```env
DVLA_API_KEY=your_key_here
```

The server calls `POST https://driver-vehicle-licensing.api.gov.uk/vehicle-enquiry/v1/vehicles` and keeps the key server-side.

## Connect MOT history

Add the credentials supplied to you by DVSA:

```env
DVSA_CLIENT_ID=...
DVSA_CLIENT_SECRET=...
DVSA_SCOPE=https://tapi.dvsa.gov.uk/.default
DVSA_TOKEN_URL=...
DVSA_API_KEY=...
```

The app obtains an OAuth client-credentials access token and calls the DVSA registration endpoint.

## Insurance / finance / stolen / write-off

These are intentionally shown as **NOT CHECKED** until you have an authorised/licensed data provider. Do not change those labels to “clear” unless an actual provider has performed the corresponding check.

## Production notes

Before public launch add rate limiting, logging, API error mapping, privacy/cookie pages, provider terms, caching rules that comply with your data licences, monitoring and HTTPS.
