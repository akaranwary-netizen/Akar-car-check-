const $ = (id) => document.getElementById(id);
const esc = (v) => String(v ?? '—').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]));
const pretty = (v) => v === true ? 'Yes' : v === false ? 'No' : (v ?? '—');
const fmtDate = (v) => { if(!v) return '—'; const d = new Date(v); return Number.isNaN(d.getTime()) ? v : d.toLocaleDateString('en-GB',{day:'2-digit',month:'short',year:'numeric'}); };

$('reg').addEventListener('input', e => {
  let s = e.target.value.toUpperCase().replace(/[^A-Z0-9 ]/g,'').replace(/\s+/g,' ');
  e.target.value = s;
});

$('checkForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  $('message').textContent = '';
  const registration = $('reg').value.trim();
  if (!registration) return $('message').textContent = 'Please enter a registration.';
  const button = e.target.querySelector('button');
  button.disabled = true; button.textContent = 'Checking…';
  try {
    const res = await fetch('/api/check',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({registration})});
    const data = await res.json();
    if(!res.ok) throw new Error(data.error || 'Check failed');
    renderReport(data);
  } catch(err) { $('message').textContent = err.message; }
  finally { button.disabled=false; button.textContent='Check car'; }
});

function renderReport(data){
  const v = data.vehicle || {};
  $('result').classList.remove('hidden');
  $('demoNotice').classList.toggle('hidden', data.source !== 'demo');
  $('vehicleTitle').textContent = [v.make, v.model].filter(Boolean).join(' ') || 'Vehicle report';
  $('plate').textContent = v.registrationNumber || $('reg').value.toUpperCase();
  $('taxStatus').textContent = v.taxStatus || '—';
  $('taxDue').textContent = v.taxDueDate ? `Due ${fmtDate(v.taxDueDate)}` : 'No due date supplied';
  $('motStatus').textContent = v.motStatus || inferMotStatus(data.mot) || '—';
  $('motDue').textContent = v.motExpiryDate ? `Expires ${fmtDate(v.motExpiryDate)}` : 'See MOT history below';

  const fields = [
    ['Make',v.make],['Model',v.model],['Colour',v.colour],['Fuel',v.fuelType],
    ['Engine capacity',v.engineCapacity ? `${v.engineCapacity} cc` : null],['Year manufactured',v.yearOfManufacture],
    ['First registration',v.monthOfFirstRegistration],['CO₂ emissions',v.co2Emissions != null ? `${v.co2Emissions} g/km` : null],
    ['Type approval',v.typeApproval],['Wheelplan',v.wheelplan],['Marked for export',pretty(v.markedForExport)],
    ['Revenue weight',v.revenueWeight ? `${v.revenueWeight} kg` : null]
  ];
  $('vehicleDetails').innerHTML = fields.map(([k,val])=>`<div class="detail"><small>${esc(k)}</small><b>${esc(val ?? '—')}</b></div>`).join('');

  const names = {insurance:'Insurance status',finance:'Outstanding finance',stolen:'Stolen vehicle',writeOff:'Insurance write-off',keeperHistory:'Keeper history',valuation:'Vehicle valuation'};
  $('riskChecks').innerHTML = Object.entries(data.checks || {}).map(([key,c])=>`<div class="check"><div><b>${esc(names[key] || key)}</b><br><span>${esc(c.note || '')}</span></div><span class="notchecked">NOT CHECKED</span></div>`).join('');
  renderMot(data.mot);
  $('result').scrollIntoView({behavior:'smooth',block:'start'});
}

function inferMotStatus(mot){
  const vehicle = Array.isArray(mot) ? mot[0] : mot;
  const tests = vehicle?.motTests || [];
  return tests[0]?.testResult || null;
}

function renderMot(mot){
  const host = $('motHistory');
  const vehicle = Array.isArray(mot) ? mot[0] : mot;
  const tests = vehicle?.motTests || [];
  if(!tests.length){host.innerHTML='<p class="muted-text">No live MOT history is connected yet. Add your DVSA credentials in <code>.env</code> to enable it.</p>';return;}
  host.innerHTML = tests.map(t => {
    const defects = t.defects || t.rfrAndComments || [];
    return `<div class="mot-test"><h4>${esc(t.testResult || 'MOT test')} · ${esc(fmtDate(t.completedDate || t.testDate))}</h4><p>Mileage: <b>${esc(t.odometerValue ?? '—')} ${esc(t.odometerUnit || '')}</b> · Expiry: <b>${esc(fmtDate(t.expiryDate))}</b></p>${defects.map(d=>`<div class="defect"><b>${esc(d.type || d.severity || 'Defect')}</b> — ${esc(d.text || d.description || '')}</div>`).join('')}</div>`;
  }).join('');
}
